# מערכת הקורסים – مسجد خالد بن الوليد

החבילה היא **עדכון חלקי לפרויקט הקיים** (לא פרויקט חדש). אין בה `node_modules`, סודות, קובצי Firebase אישיים, או תוצרי Build.

## מה נכלל

- משתמשים רגילים: רשימת קורסים, הרשמה ללא חשבון, צפייה בסטטוס ב־`تسجيلاتي` מאותה התקנת אפליקציה.
- מנהלים: יצירה ועריכה של קורסים, סגירה וארכוב, צפייה בנרשמים, אישור/דחייה ושליחה חוזרת של הודעת Push.
- הרשמה אוטומטית או טעונת אישור. מקום נשמר כבר בעת הגשת הבקשה הממתינה, כדי לא לעבור את התפוסה בזמן אישור.
- הרשמות ומספרי טלפון נשמרים באוסף פרטי שניתן לקרוא רק כמנהל מאומת. כל שינויי הקורסים וההרשמות מבוצעים ב־Cloud Functions.
- FCM Token נשמר עם ההרשמה. המכשיר מחזיק מפתח התקנה אקראי, שבאמצעותו מתעדכנים Tokens ומשתקף מצב הבקשות. אין מעקב GPS ואין זיהוי אמיתי של מספר טלפון/אדם.
- הרשמה כפולה מאותו מספר כפי **שהוזן** לאותו קורס נחסמת. אין אימות בעלות על המספר!

## התקנה ב-Windows PowerShell

פתחו PowerShell בתיקיית הפרויקט:

```powershell
cd C:\development\projects\masjid_khalid_app
git status
# מומלץ: אם אין שינויים לא-שמורים, ליצור ענף חדש
# git switch -c feature/courses-20261124
Expand-Archive -LiteralPath .\masjid_courses_patch_2026-11-24.zip -DestinationPath .\course_update -Force
.\course_update\APPLY_COURSES.ps1
flutter pub get
flutter analyze
```

הסקריפט מגבה קבצים קיימים לתיקיית גיבוי מחוץ לפרויקט, מעתיק רק קבצים מהרשימה המאושרת, ולא מפעיל פריסה לענן.

### בדיקת Functions (לפני פריסה)

```powershell
cd C:\development\projects\masjid_khalid_app\functions
npm ci
npm run lint
cd ..
```

### פריסה ל-Firebase

```powershell
firebase use
firebase deploy --only firestore:rules
firebase deploy --only functions:saveCourse,functions:archiveCourse,functions:registerForCourse,functions:syncCourseDeviceToken,functions:myCourseRegistrations,functions:decideCourseRegistration,functions:resendCourseDecision
flutter run
```

יש לבצע פריסה רק לאחר בדיקה שהפרויקט שבפקודת `firebase use` הוא הפרויקט הנכון וש־`flutter analyze` ו־`npm run lint` עוברים. לא להריץ את הפקודות עד שיש גיבוי/commit למצב הנוכחי.

## בדיקת פונקציונליות

1. היכנס כמנהל, פתח `الدورات`, צור קורס עתידי בתפוסה 2 עם מצב אישור מנהל.
2. צא מהחשבון. פתח `الدورات`, הירשם כמשתמש רגיל, אפשר הודעות.
3. במסך `تسجيلاتي` ודא שהבקשה `بانتظار موافقة المسؤول`.
4. היכנס כמנהל, פתח `المسجلون`, אשר בקשה. ודא שהסטטוס הופך למאושר במכשיר הציבורי, ושבמכשיר מופיעה התראה אם ההרשאות והתשתית תקינות.
5. נסה להירשם שוב עם אותו מספר טלפון לקורס – תתקבל הודעת כפל.
6. נסה לעבור את התפוסה; בדוק גם הרשמה אוטומטית, דחייה, שליחה חוזרת, ארכוב ומצב לילה.

## הכנות/מגבלות לפני הפצה

- **FCM Android:** רצוי לבדוק במכשיר או באמולטור עם Google Play Services. התראות דורשות הרשאת מערכת; בדיקת סטטוס אפשרית גם בלעדיה. שליחת הודעה על ידי FCM אינה מבטיחה שהתקבלה/נקראה בפועל.
- **FCM iOS:** נדרש מחשב Mac עם Xcode, הפעלת Push Notifications ו־Background Modes, העלאת מפתח APNs לפרויקט Firebase, ובדיקה במכשיר iOS. הקוד ב־AppDelegate עודכן ל־firebase_messaging 17.x.
- **אבטחת הרשמות ציבוריות:** קיים Rate Limiting בסיסי לכל IP ולמפתח התקנה. לפני הפצה ציבורית **יש להגדיר Firebase App Check ולהפעיל enforcement על פונקציות הציבוריות**, ולבחון מניעת בוטים נוספת. אין בשלב זה אימות מספר טלפון או OTP, ולכן משתמש יכול להקליד מספר של אדם אחר.
- **פרטיות/שמירת מידע:** מחיקה/ארכוב של קורס אינה מוחקת רשומות הרשמה פרטיות. יש לקבוע מדיניות שמירת מידע ומחיקה לפי צורך לפני הפצה.
- **TTL:** מומלץ להפעיל מדיניות TTL ב־Firestore עבור collection group `security_course_registration_limits`, בשדה `expiresAt`, כדי לנקות רשומות מגבלות ישנות אוטומטית.
- **`تسجيلاتي`:** מציג רק סטטוסים של בקשות שנשלחו מאותה התקנת אפליקציה. אם המשתמש מוחק נתוני אפליקציה או מתקין אותה מחדש, מפתח ההתקנה אובד ואין גישה לבדיקה זו. יש לבקש סיוע מהמנהל במקרה זה. משתמשים שמשתפים את אותו מכשיר יכולים לראות את סטטוס הבקשות של אותו מכשיר (ללא שם וטלפון).
- **לוח מועדים:** בשלב זה לכל קורס יש מועד התחלה יחיד; מערכת מפגשים חוזרים אינה חלק מהחבילה.
- **בדיקות:** בדיקת `node --check`, ESLint ובדיקת לוגיקה מדומה עברו בסביבת ההכנה. Flutter SDK ופרויקט Firebase לא היו זמינים להרצה מלאה כאן, ולכן נדרשות בדיקות `flutter analyze`, אמולטור ו־Firebase אצלך.

## קבצים שהשתנו/נוספו

- `lib/main.dart`, `lib/models/course.dart`, `lib/screens/courses_page.dart`, `lib/screens/course_editor_dialog.dart`, `lib/screens/course_registration_dialog.dart`, `lib/screens/course_registrations_page.dart`
- `lib/services/courses_service.dart`, `lib/services/course_notifications_service.dart`
- `functions/index.js`, `functions/courses.js`, `firestore.rules`, `pubspec.yaml`
- `android/app/src/main/AndroidManifest.xml`, `ios/Runner/AppDelegate.swift`

## שחזור

במקרה של תקלה, חזור ל־commit/branch הקודם באמצעות Git, או שחזר את הקבצים מתיקיית הגיבוי שהסקריפט יוצר ליד תיקיית הפרויקט. אין להשתמש ב־`git reset --hard` אם קיימים שינויים חשובים שלא נשמרו.
