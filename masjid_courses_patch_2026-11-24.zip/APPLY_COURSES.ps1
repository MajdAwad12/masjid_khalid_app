$ErrorActionPreference = 'Stop'

# This file is executed from the extracted course_update folder.
$Project = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not (Test-Path -LiteralPath (Join-Path $Project 'pubspec.yaml'))) {
    throw 'Place the extracted course_update folder inside the Flutter project root.'
}
if (-not (Test-Path -LiteralPath (Join-Path $Project 'functions\index.js'))) {
    throw 'The target project does not have functions\index.js.'
}

$Files = @(
    'lib\main.dart',
    'lib\models\course.dart',
    'lib\screens\courses_page.dart',
    'lib\screens\course_editor_dialog.dart',
    'lib\screens\course_registration_dialog.dart',
    'lib\screens\course_registrations_page.dart',
    'lib\services\courses_service.dart',
    'lib\services\course_notifications_service.dart',
    'functions\index.js',
    'functions\courses.js',
    'firestore.rules',
    'pubspec.yaml',
    'android\app\src\main\AndroidManifest.xml',
    'ios\Runner\AppDelegate.swift'
)

# Check all source files exist BEFORE touching the working project.
foreach ($Relative in $Files) {
    $Source = Join-Path $PSScriptRoot $Relative
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
        throw "Missing update file: $Relative"
    }
}

$Parent = (Resolve-Path (Join-Path $Project '..')).Path
$Backup = Join-Path $Parent ('masjid_courses_backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -Path $Backup -ItemType Directory -Force | Out-Null

foreach ($Relative in $Files) {
    $Source = Join-Path $PSScriptRoot $Relative
    $Destination = Join-Path $Project $Relative
    $DestinationParent = Split-Path -Path $Destination -Parent
    New-Item -Path $DestinationParent -ItemType Directory -Force | Out-Null

    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        $BackupFile = Join-Path $Backup $Relative
        $BackupParent = Split-Path -Path $BackupFile -Parent
        New-Item -Path $BackupParent -ItemType Directory -Force | Out-Null
        Copy-Item -LiteralPath $Destination -Destination $BackupFile -Force
    }
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    Write-Host "Updated: $Relative"
}

Write-Host "Backup folder: $Backup"
Write-Host 'Files copied. Next: flutter pub get; flutter analyze; npm run lint.'
Write-Host 'Nothing was deployed to Firebase automatically.'
