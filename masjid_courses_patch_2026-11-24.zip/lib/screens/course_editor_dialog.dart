import 'package:material_ui/material_ui.dart';

import '../models/course.dart';
import '../services/courses_service.dart';
import '../widgets/app_theme.dart';

class CourseEditorDialog extends StatefulWidget {
  final Course? existing;

  const CourseEditorDialog({super.key, this.existing});

  @override
  State<CourseEditorDialog> createState() => _CourseEditorDialogState();
}

class _CourseEditorDialogState extends State<CourseEditorDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _description;
  late final TextEditingController _teacher;
  late final TextEditingController _location;
  late final TextEditingController _capacity;
  late DateTime _startAt;
  late String _registrationMode;
  late bool _isOpen;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final item = widget.existing;
    _title = TextEditingController(text: item?.title ?? '');
    _description = TextEditingController(text: item?.description ?? '');
    _teacher = TextEditingController(text: item?.teacher ?? '');
    _location = TextEditingController(text: item?.location ?? 'المسجد');
    _capacity = TextEditingController(
      text: item?.capacity.toString() ?? '30',
    );
    _startAt = item?.startAt ?? DateTime.now().add(const Duration(days: 7));
    _registrationMode = item?.registrationMode ?? 'approval';
    _isOpen = item?.isOpen ?? true;
  }

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    _teacher.dispose();
    _location.dispose();
    _capacity.dispose();
    super.dispose();
  }

  Future<void> _pickStart() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _startAt,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_startAt),
    );
    if (time == null || !mounted) return;
    setState(() {
      _startAt = DateTime(
        date.year, date.month, date.day, time.hour, time.minute,
      );
    });
  }

  Future<void> _save() async {
    if (_saving || !_formKey.currentState!.validate()) return;
    if (widget.existing == null && !_startAt.isAfter(DateTime.now())) {
      _notice('اختر موعدًا مستقبليًا للدورة');
      return;
    }
    setState(() => _saving = true);
    try {
      await CoursesService.saveCourse(
        existing: widget.existing,
        title: _title.text,
        description: _description.text,
        teacher: _teacher.text,
        location: _location.text,
        startAt: _startAt,
        capacity: int.parse(_capacity.text.trim()),
        registrationMode: _registrationMode,
        isOpen: _isOpen,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      _notice(CoursesService.errorMessage(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _notice(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  String? _required(String? value, int min, int max) {
    final length = value?.trim().length ?? 0;
    if (length < min || length > max) {
      return 'يرجى إدخال نص بين $min و$max حرفًا';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.existing == null ? 'إضافة دورة جديدة' : 'تعديل الدورة'),
      content: SizedBox(
        width: 510,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _title,
                  maxLength: 90,
                  decoration: const InputDecoration(labelText: 'اسم الدورة'),
                  validator: (v) => _required(v, 3, 90),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _description,
                  maxLength: 1200,
                  minLines: 3,
                  maxLines: 5,
                  decoration: const InputDecoration(labelText: 'وصف الدورة'),
                  validator: (v) => _required(v, 1, 1200),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _teacher,
                  maxLength: 80,
                  decoration: const InputDecoration(labelText: 'اسم المحاضر'),
                  validator: (v) => _required(v, 1, 80),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _location,
                  maxLength: 120,
                  decoration: const InputDecoration(labelText: 'مكان الدورة'),
                  validator: (v) => _required(v, 1, 120),
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _capacity,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'عدد الأماكن المتاحة',
                  ),
                  validator: (value) {
                    final n = int.tryParse(value?.trim() ?? '');
                    if (n == null || n < 1 || n > 1000) {
                      return 'أدخل عددًا بين 1 و1000';
                    }
                    if (widget.existing != null &&
                        n < widget.existing!.occupied) {
                      return 'لا يمكن تقليل العدد عن التسجيلات الحالية';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _saving ? null : _pickStart,
                  icon: const Icon(Icons.event_outlined),
                  label: Text('موعد الدورة: ${_format(_startAt)}'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _registrationMode,
                  decoration: const InputDecoration(labelText: 'نوع التسجيل'),
                  items: const [
                    DropdownMenuItem(
                      value: 'approval',
                      child: Text('يحتاج موافقة المسؤول'),
                    ),
                    DropdownMenuItem(
                      value: 'automatic',
                      child: Text('تسجيل تلقائي'),
                    ),
                  ],
                  onChanged: _saving
                      ? null
                      : (value) => setState(() {
                          if (value != null) _registrationMode = value;
                        }),
                ),
                const SizedBox(height: 5),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('فتح التسجيل'),
                  subtitle: const Text('يمكن إغلاق التسجيل دون حذف الدورة'),
                  value: _isOpen,
                  activeThumbColor: AppColors.gold,
                  onChanged: _saving
                      ? null
                      : (value) => setState(() => _isOpen = value),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.pop(context, false),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: _saving ? null : _save,
          child: _saving
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('حفظ الدورة'),
        ),
      ],
    );
  }

  String _format(DateTime time) {
    String p(int x) => x.toString().padLeft(2, '0');
    return '${p(time.day)}/${p(time.month)}/${time.year}  '
        '${p(time.hour)}:${p(time.minute)}';
  }
}
