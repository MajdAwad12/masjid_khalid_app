import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';

import '../models/course.dart';
import '../services/courses_service.dart';
import '../widgets/app_theme.dart';

class CourseRegistrationsPage extends StatefulWidget {
  final Course course;

  const CourseRegistrationsPage({super.key, required this.course});

  @override
  State<CourseRegistrationsPage> createState() =>
      _CourseRegistrationsPageState();
}

class _CourseRegistrationsPageState extends State<CourseRegistrationsPage> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream;
  String? _busyId;

  @override
  void initState() {
    super.initState();
    _stream = FirebaseFirestore.instance.collection('course_registrations')
        .where('courseId', isEqualTo: widget.course.id).snapshots();
  }

  void _notice(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _decide(String registrationId, String decision) async {
    if (_busyId != null) return;
    final accept = decision == 'accepted';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(accept ? 'الموافقة على التسجيل' : 'رفض التسجيل'),
        content: Text(accept
            ? 'هل تريد قبول طلب التسجيل؟'
            : 'هل تريد رفض طلب التسجيل؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _busyId = registrationId);
    try {
      final notified = await CoursesService.decide(
        courseId: widget.course.id,
        registrationId: registrationId,
        decision: decision,
      );
      _notice(notified
          ? 'تم حفظ القرار وإرسال الإشعار'
          : 'تم حفظ القرار، لكن تعذر إرسال الإشعار. '
              'يمكن إعادة المحاولة بعد التحقق من إعدادات الهاتف.');
    } catch (error) {
      _notice(CoursesService.errorMessage(error));
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }

  Future<void> _resend(String registrationId) async {
    if (_busyId != null) return;
    setState(() => _busyId = registrationId);
    try {
      final notified = await CoursesService.resend(
        courseId: widget.course.id,
        registrationId: registrationId,
      );
      _notice(notified
          ? 'تم طلب إرسال الإشعار مجددًا'
          : 'لم يتم إرسال الإشعار. تأكد من إعدادات جهاز المستفيد.');
    } catch (error) {
      _notice(CoursesService.errorMessage(error));
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }

  String _status(String value) {
    switch (value) {
      case 'accepted':
        return 'مقبول';
      case 'rejected':
        return 'مرفوض';
      default:
        return 'بانتظار الموافقة';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة المسجلين')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: _stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Text('تعذر تحميل قائمة المسجلين'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final registrations = snapshot.data!.docs.toList()
            ..sort((a, b) {
              final aDate = a.data()['createdAt'];
              final bDate = b.data()['createdAt'];
              final aMillis = aDate is Timestamp ? aDate.millisecondsSinceEpoch : 0;
              final bMillis = bDate is Timestamp ? bDate.millisecondsSinceEpoch : 0;
              return bMillis.compareTo(aMillis);
            });
          if (registrations.isEmpty) {
            return const Center(child: Text('لا توجد تسجيلات لهذه الدورة'));
          }
          return Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 700),
              child: ListView(
                padding: const EdgeInsets.all(18),
                children: [
                  Text(
                    widget.course.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'عدد الطلبات: ${registrations.length}',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 20),
                  ...registrations.map((doc) {
                    final data = doc.data();
                    final status = (data['status'] ?? 'pending').toString();
                    final state = (data['notificationState'] ?? '').toString();
                    final isBusy = _busyId == doc.id;
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              (data['fullName'] ?? '').toString(),
                              style: const TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 6),
                            SelectableText(
                              'رقم الهاتف: ${(data['phone'] ?? '').toString()}',
                            ),
                            const SizedBox(height: 7),
                            Text(
                              'الحالة: ${_status(status)}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                                color: AppColors.gold,
                              ),
                            ),
                            if (status != 'pending') ...[
                              const SizedBox(height: 5),
                              Text(
                                state == 'sent'
                                    ? 'تم طلب إرسال الإشعار'
                                    : 'لم يتم تأكيد إرسال إشعار للمستفيد',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Theme.of(context)
                                      .colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                            const SizedBox(height: 12),
                            if (status == 'pending')
                              Wrap(
                                spacing: 9,
                                runSpacing: 8,
                                children: [
                                  ElevatedButton.icon(
                                    onPressed: _busyId == null
                                        ? () => _decide(doc.id, 'accepted')
                                        : null,
                                    icon: const Icon(Icons.check_circle_outline),
                                    label: const Text('قبول'),
                                  ),
                                  OutlinedButton.icon(
                                    onPressed: _busyId == null
                                        ? () => _decide(doc.id, 'rejected')
                                        : null,
                                    icon: const Icon(Icons.cancel_outlined),
                                    label: const Text('رفض'),
                                  ),
                                ],
                              )
                            else
                              TextButton.icon(
                                onPressed: _busyId == null
                                    ? () => _resend(doc.id)
                                    : null,
                                icon: const Icon(Icons.notifications_active_outlined),
                                label: const Text('إعادة إرسال الإشعار'),
                              ),
                            if (isBusy)
                              const LinearProgressIndicator(minHeight: 2),
                          ],
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
