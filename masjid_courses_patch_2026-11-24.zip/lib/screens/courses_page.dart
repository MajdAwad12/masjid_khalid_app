import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:material_ui/material_ui.dart';

import '../models/course.dart';
import '../services/course_notifications_service.dart';
import '../services/courses_service.dart';
import '../widgets/app_theme.dart';
import 'course_editor_dialog.dart';
import 'course_registration_dialog.dart';
import 'course_registrations_page.dart';

class CoursesPage extends StatefulWidget {
  final bool isAdmin;

  const CoursesPage({super.key, required this.isAdmin});

  @override
  State<CoursesPage> createState() => _CoursesPageState();
}

class _CoursesPageState extends State<CoursesPage> {
  late final Stream<QuerySnapshot<Map<String, dynamic>>> _stream;
  String? _archivingId;
  Timer? _clockRefresh;

  @override
  void initState() {
    super.initState();
    _stream = FirebaseFirestore.instance.collection('courses')
        .orderBy('startAt').snapshots();
    _clockRefresh = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _clockRefresh?.cancel();
    super.dispose();
  }

  void _notice(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _openEditor([Course? course]) async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => CourseEditorDialog(existing: course),
    );
    if (saved == true) {
      _notice(course == null ? 'تم نشر الدورة بنجاح' : 'تم تعديل الدورة بنجاح');
    }
  }

  Future<void> _archive(Course course) async {
    if (_archivingId != null) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('أرشفة الدورة'),
        content: const Text(
          'ستختفي الدورة من القائمة العامة وتبقى بيانات التسجيل محفوظة '
          'لدى الإدارة. هل تريد المتابعة؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('أرشفة'),
          ),
        ],
      ),
    );
    if (confirm != true || !mounted) return;
    setState(() => _archivingId = course.id);
    try {
      await CoursesService.archiveCourse(course.id);
      _notice('تمت أرشفة الدورة');
    } catch (error) {
      _notice(CoursesService.errorMessage(error));
    } finally {
      if (mounted) setState(() => _archivingId = null);
    }
  }

  Future<void> _register(Course course) async {
    final status = await showDialog<String>(
      context: context,
      builder: (_) => CourseRegistrationDialog(course: course),
    );
    if (!mounted || status == null) return;
    if (status == 'accepted') {
      _notice('تم تسجيلك بنجاح في الدورة');
    } else {
      _notice('تم إرسال طلبك وهو بانتظار موافقة المسؤول');
    }
  }

  Future<void> _showMyRegistrations(List<Course> courses) async {
    final key = await CourseNotificationsService.instance.existingDeviceKey();
    if (!mounted) return;
    if (key == null) {
      _notice('لم تسجل في أي دورة من هذا الجهاز بعد');
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تسجيلاتي'),
        content: SizedBox(
          width: 480,
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: CoursesService.myRegistrations(key),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Text(CoursesService.errorMessage(snapshot.error!));
              }
              if (!snapshot.hasData) {
                return const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              final entries = snapshot.data!;
              if (entries.isEmpty) {
                return const Text('لا توجد تسجيلات من هذا الجهاز');
              }
              final names = {
                for (final course in courses) course.id: course.title,
              };
              return ListView.separated(
                shrinkWrap: true,
                itemCount: entries.length,
                separatorBuilder: (_, _) => const Divider(height: 12),
                itemBuilder: (_, index) {
                  final entry = entries[index];
                  final title = names[entry['courseId']] ?? 'دورة سابقة';
                  final status = entry['status'];
                  final statusLabel = status == 'accepted'
                      ? 'تم قبول التسجيل'
                      : status == 'rejected'
                          ? 'تم رفض التسجيل'
                          : 'بانتظار موافقة المسؤول';
                  return ListTile(
                    title: Text(title),
                    subtitle: Text(statusLabel),
                    leading: Icon(
                      status == 'accepted'
                          ? Icons.check_circle_outline
                          : status == 'rejected'
                              ? Icons.cancel_outlined
                              : Icons.schedule_outlined,
                      color: AppColors.gold,
                    ),
                  );
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _stream,
      builder: (context, snapshot) {
        final all = snapshot.data?.docs.map(Course.fromDocument).toList()
            ?? <Course>[];
        final courses = widget.isAdmin
            ? all
            : all.where((course) => !course.archived).toList();
        return Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
              children: [
                const Icon(
                  Icons.school_outlined,
                  size: 42,
                  color: AppColors.gold,
                ),
                const SizedBox(height: 10),
                Text(
                  'الدورات',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: scheme.onSurface,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  'اكتشف الدورات وسجّل للمشاركة',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 15,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 20),
                if (widget.isAdmin)
                  ElevatedButton.icon(
                    onPressed: _archivingId == null
                        ? () => _openEditor()
                        : null,
                    icon: const Icon(Icons.add_circle_outline),
                    label: const Text('إضافة دورة جديدة'),
                  )
                else
                  OutlinedButton.icon(
                    onPressed: snapshot.hasData
                        ? () => _showMyRegistrations(all)
                        : null,
                    icon: const Icon(Icons.assignment_outlined),
                    label: const Text('تسجيلاتي'),
                  ),
                const SizedBox(height: 20),
                if (snapshot.hasError)
                  const _CourseEmptyMessage(
                    icon: Icons.error_outline,
                    message: 'تعذر تحميل الدورات. تحقق من الاتصال بالإنترنت.',
                  )
                else if (!snapshot.hasData)
                  const Padding(
                    padding: EdgeInsets.only(top: 55),
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (courses.isEmpty)
                  const _CourseEmptyMessage(
                    icon: Icons.school_outlined,
                    message: 'لا توجد دورات متاحة حاليًا',
                  )
                else
                  ...courses.map((course) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: _CourseCard(
                      course: course,
                      isAdmin: widget.isAdmin,
                      busy: _archivingId != null,
                      onRegister: () => _register(course),
                      onEdit: () => _openEditor(course),
                      onArchive: () => _archive(course),
                      onRegistrations: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => CourseRegistrationsPage(
                            course: course,
                          ),
                        ),
                      ),
                    ),
                  )),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CourseEmptyMessage extends StatelessWidget {
  final IconData icon;
  final String message;

  const _CourseEmptyMessage({required this.icon, required this.message});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 52),
      child: Column(
        children: [
          Icon(icon, size: 45, color: AppColors.gold),
          const SizedBox(height: 15),
          Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _CourseCard extends StatelessWidget {
  final Course course;
  final bool isAdmin;
  final bool busy;
  final VoidCallback onRegister;
  final VoidCallback onEdit;
  final VoidCallback onArchive;
  final VoidCallback onRegistrations;

  const _CourseCard({
    required this.course,
    required this.isAdmin,
    required this.busy,
    required this.onRegister,
    required this.onEdit,
    required this.onArchive,
    required this.onRegistrations,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final canRegister = course.canRegister;
    final isFull = course.occupied >= course.capacity;
    final label = course.archived
        ? 'مؤرشفة'
        : !course.isOpen ||
                course.startAt == null ||
                !course.startAt!.isAfter(DateTime.now())
            ? 'التسجيل مغلق'
            : isFull
                ? 'اكتملت الأماكن'
                : 'التسجيل مفتوح';
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: scheme.outlineVariant),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    course.title,
                    style: TextStyle(
                      color: scheme.onSurface,
                      fontSize: 19,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: canRegister ? AppColors.gold :
                        scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              course.description,
              style: TextStyle(color: scheme.onSurfaceVariant, height: 1.5),
            ),
            const SizedBox(height: 15),
            _line(Icons.person_outline, 'المحاضر: ${course.teacher}', scheme),
            const SizedBox(height: 7),
            _line(Icons.event_outlined, 'الموعد: ${course.formattedStart}', scheme),
            const SizedBox(height: 7),
            _line(Icons.place_outlined, 'المكان: ${course.location}', scheme),
            const SizedBox(height: 7),
            _line(
              Icons.groups_outlined,
              'الأماكن المتبقية: ${course.capacity - course.occupied} '
              'من ${course.capacity}',
              scheme,
            ),
            if (isAdmin) ...[
              const SizedBox(height: 7),
              _line(
                Icons.pending_actions_outlined,
                'بانتظار الموافقة: ${course.pendingCount}  ·  '
                'المقبولون: ${course.acceptedCount}',
                scheme,
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 9,
                runSpacing: 8,
                children: [
                  OutlinedButton.icon(
                    onPressed: busy || course.archived ? null : onEdit,
                    icon: const Icon(Icons.edit_outlined),
                    label: const Text('تعديل'),
                  ),
                  OutlinedButton.icon(
                    onPressed: busy ? null : onRegistrations,
                    icon: const Icon(Icons.people_outline),
                    label: const Text('المسجلون'),
                  ),
                  TextButton.icon(
                    onPressed: busy || course.archived ? null : onArchive,
                    icon: const Icon(Icons.archive_outlined),
                    label: const Text('أرشفة'),
                  ),
                ],
              ),
            ] else ...[
              const SizedBox(height: 15),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: canRegister ? onRegister : null,
                  child: const Text('التسجيل في الدورة'),
                ),
              ),
              if (course.registrationMode == 'approval' && canRegister)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    'التسجيل يحتاج إلى موافقة المسؤول',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: scheme.onSurfaceVariant,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _line(IconData icon, String text, ColorScheme scheme) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 17, color: AppColors.gold),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            text,
            style: TextStyle(fontSize: 13, color: scheme.onSurfaceVariant),
          ),
        ),
      ],
    );
  }
}
