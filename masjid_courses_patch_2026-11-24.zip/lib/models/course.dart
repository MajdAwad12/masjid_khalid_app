import 'package:cloud_firestore/cloud_firestore.dart';

class Course {
  final String id;
  final String title;
  final String description;
  final String teacher;
  final String location;
  final DateTime? startAt;
  final int capacity;
  final int acceptedCount;
  final int pendingCount;
  final bool isOpen;
  final bool archived;
  final String registrationMode;

  const Course({
    required this.id,
    required this.title,
    required this.description,
    required this.teacher,
    required this.location,
    required this.startAt,
    required this.capacity,
    required this.acceptedCount,
    required this.pendingCount,
    required this.isOpen,
    required this.archived,
    required this.registrationMode,
  });

  factory Course.fromDocument(DocumentSnapshot<Map<String, dynamic>> doc) {
    final map = doc.data() ?? <String, dynamic>{};
    final startAt = map['startAt'];
    return Course(
      id: doc.id,
      title: (map['title'] ?? '').toString(),
      description: (map['description'] ?? '').toString(),
      teacher: (map['teacher'] ?? '').toString(),
      location: (map['location'] ?? '').toString(),
      startAt: startAt is Timestamp ? startAt.toDate().toLocal() : null,
      capacity: (map['capacity'] as num?)?.toInt() ?? 0,
      acceptedCount: (map['acceptedCount'] as num?)?.toInt() ?? 0,
      pendingCount: (map['pendingCount'] as num?)?.toInt() ?? 0,
      isOpen: map['isOpen'] == true,
      archived: map['archived'] == true,
      registrationMode: (map['registrationMode'] ?? 'approval').toString(),
    );
  }

  int get occupied => acceptedCount + pendingCount;

  bool get canRegister =>
      !archived &&
      isOpen &&
      occupied < capacity &&
      startAt != null &&
      startAt!.isAfter(DateTime.now());

  String get formattedStart {
    final time = startAt;
    if (time == null) return 'لم يحدد';
    String pad(int number) => number.toString().padLeft(2, '0');
    return '${pad(time.day)}/${pad(time.month)}/${time.year}  '
        '${pad(time.hour)}:${pad(time.minute)}';
  }
}
