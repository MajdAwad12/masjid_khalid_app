"use strict";

/* eslint-disable require-jsdoc, valid-jsdoc */

// Course registration is available without Firebase Authentication.
// Only server code can write courses and registrations; admins are checked
// against BOTH Firebase custom claims and the admin profile in index.js.
const crypto = require("node:crypto");
const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {FieldValue, Timestamp} = require("firebase-admin/firestore");
const {getMessaging} = require("firebase-admin/messaging");
const logger = require("firebase-functions/logger");

const hash = (value) => crypto.createHash("sha256")
    .update(value).digest("hex");
const keyPattern = /^[a-f0-9]{64}$/;
const tokenPattern = /^.{20,4096}$/s;
const registrationStates = ["pending", "accepted", "rejected"];

/** Validate a required user-entered text field. */
function limitedText(value, field, max, min = 1) {
  if (typeof value !== "string") {
    throw new HttpsError("invalid-argument", `${field} is required.`);
  }
  const text = value.trim();
  if (text.length < min || text.length > max) {
    throw new HttpsError("invalid-argument", `Invalid ${field}.`);
  }
  return text;
}

/** Validate and hash the installation credential. */
function validDeviceKey(value) {
  if (typeof value !== "string" || !keyPattern.test(value)) {
    throw new HttpsError("invalid-argument",
        "Invalid device registration key.");
  }
  return hash(`course-device\0${value}`);
}

/** Validate the optional FCM registration token. */
function validToken(value) {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value !== "string" || !tokenPattern.test(value)) {
    throw new HttpsError("invalid-argument", "Invalid notification token.");
  }
  return value;
}

/** Normalize a submitted phone number for duplicate suppression. */
function normalizePhone(value) {
  if (typeof value !== "string" || value.length > 32 ||
      !/^[+\d\s()-]+$/.test(value)) {
    throw new HttpsError("invalid-argument", "Invalid phone number.");
  }
  let digits = value.replace(/\D/g, "");
  // Standardize common Israeli local/international spellings for duplicates.
  if (digits.startsWith("00972")) digits = digits.substring(2);
  if (digits.startsWith("9720")) digits = `972${digits.substring(4)}`;
  if (digits.startsWith("0") && digits.length === 10) {
    digits = `972${digits.substring(1)}`;
  }
  if (digits.length < 8 || digits.length > 15) {
    throw new HttpsError("invalid-argument", "Invalid phone number.");
  }
  return digits;
}

/** Validate a server-generated course document ID. */
function requireCourseId(value) {
  if (typeof value !== "string" || !/^[a-zA-Z0-9]{10,40}$/.test(value)) {
    throw new HttpsError("invalid-argument", "Invalid course ID.");
  }
  return value;
}

/** Validate a hash-derived registration ID. */
function requireRegistrationId(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) {
    throw new HttpsError("invalid-argument", "Invalid registration ID.");
  }
  return value;
}

// The rate limiter does not store raw IP addresses, phone numbers, or tokens.
// A shared mosque Wi-Fi may have many users, hence the fairly generous limit.
/** Limit public enrollment submissions per hour. */
async function rateLimitPublicRegistration(db, request, deviceKeyHash) {
  const ip = request.rawRequest?.ip;
  if (typeof ip !== "string" || ip.length < 2) {
    throw new HttpsError("unavailable", "Unable to verify request origin.");
  }
  const now = Date.now();
  const hourlyWindow = Math.floor(now / 3600000);
  const limits = [
    {id: hash(`course-ip\0${ip}\0${hourlyWindow}`), max: 60},
    {id: hash(`course-device-limit\0${deviceKeyHash}\0${hourlyWindow}`),
      max: 8},
  ];
  const refs = limits.map((item) => db.collection(
      "security_course_registration_limits").doc(item.id));
  await db.runTransaction(async (tx) => {
    const snapshots = await Promise.all(refs.map((ref) => tx.get(ref)));
    for (let i = 0; i < refs.length; i++) {
      const count = Number(snapshots[i].get("count")) || 0;
      if (count >= limits[i].max) {
        throw new HttpsError("resource-exhausted", "Too many registrations.");
      }
    }
    for (let i = 0; i < refs.length; i++) {
      tx.set(refs[i], {
        count: (Number(snapshots[i].get("count")) || 0) + 1,
        expiresAt: Timestamp.fromMillis((hourlyWindow + 2) * 3600000),
      });
    }
  });
}

/** Validate a course edited by an administrator. */
function parseCourse(data) {
  const title = limitedText(data.title, "title", 90, 3);
  const description = limitedText(data.description, "description", 1200);
  const teacher = limitedText(data.teacher, "teacher", 80);
  const location = limitedText(data.location, "location", 120);
  if (!Number.isInteger(data.capacity) || data.capacity < 1 ||
      data.capacity > 1000) {
    throw new HttpsError("invalid-argument", "Capacity must be 1–1000.");
  }
  if (!Number.isSafeInteger(data.startAtMs) ||
      data.startAtMs < Date.UTC(2020, 0, 1) ||
      data.startAtMs > Date.UTC(2100, 0, 1)) {
    throw new HttpsError("invalid-argument", "Invalid course start date.");
  }
  if (!["automatic", "approval"].includes(data.registrationMode)) {
    throw new HttpsError("invalid-argument", "Invalid registration mode.");
  }
  if (typeof data.isOpen !== "boolean") {
    throw new HttpsError("invalid-argument", "Invalid course status.");
  }
  return {
    title, description, teacher, location,
    capacity: data.capacity,
    startAt: Timestamp.fromMillis(data.startAtMs),
    registrationMode: data.registrationMode,
    isOpen: data.isOpen,
  };
}

/** Send an FCM decision notification; record delivery request status. */
async function sendDecision(db, courseId, registrationId, registration) {
  const ref = db.collection("course_registrations").doc(registrationId);
  const token = registration.fcmToken;
  if (typeof token !== "string" || !token) {
    await ref.update({notificationState: "no-token"});
    return false;
  }
  const accepted = registration.status === "accepted";
  const title = accepted ? "تم قبول تسجيلك في الدورة" :
    "تم رفض طلب التسجيل في الدورة";
  const body = accepted ? "يسعدنا انضمامك إلى الدورة. أهلاً بك!" :
    "نعتذر، لم تتم الموافقة على طلب تسجيلك.";
  try {
    await getMessaging().send({
      token,
      notification: {title, body},
      data: {type: "course_decision", courseId, registrationId,
        status: registration.status},
      android: {priority: "high"},
      apns: {payload: {aps: {sound: "default"}}},
    });
    await ref.update({notificationState: "sent",
      notifiedAt: FieldValue.serverTimestamp()});
    return true;
  } catch (error) {
    logger.warn("Course decision push failed", {
      registrationId, code: error.code || "unknown",
    });
    await ref.update({notificationState: "failed"});
    return false;
  }
}

/** Bind all course Cloud Functions to the existing admin checker and DB. */
function makeCourseFunctions({db, requireAdmin}) {
  return {
    // Course writes are all validated and authorized server-side.
    saveCourse: onCall({region: "us-central1", maxInstances: 10},
        async (request) => {
          const adminUid = await requireAdmin(request);
          const data = request.data || {};
          const validated = parseCourse(data);
          const courseId = data.courseId == null ? null :
            requireCourseId(data.courseId);
          const ref = courseId ? db.collection("courses").doc(courseId) :
            db.collection("courses").doc();
          await db.runTransaction(async (tx) => {
            const snap = await tx.get(ref);
            if (courseId && !snap.exists) {
              throw new HttpsError("not-found", "Course not found.");
            }
            if (snap.exists && snap.get("archived") === true) {
              throw new HttpsError("failed-precondition", "Course archived.");
            }
            const occupied = (Number(snap.get("acceptedCount")) || 0) +
                (Number(snap.get("pendingCount")) || 0);
            if (validated.capacity < occupied) {
              throw new HttpsError("failed-precondition",
                  "Capacity below existing registrations.");
            }
            if (snap.exists) {
              tx.update(ref, {...validated, updatedBy: adminUid,
                updatedAt: FieldValue.serverTimestamp()});
            } else {
              tx.create(ref, {...validated, archived: false,
                acceptedCount: 0, pendingCount: 0,
                createdAt: FieldValue.serverTimestamp(),
                updatedAt: FieldValue.serverTimestamp(),
                createdBy: adminUid, updatedBy: adminUid});
            }
          });
          return {courseId: ref.id};
        }),

    archiveCourse: onCall({region: "us-central1", maxInstances: 10},
        async (request) => {
          const adminUid = await requireAdmin(request);
          const id = requireCourseId(request.data?.courseId);
          const ref = db.collection("courses").doc(id);
          await db.runTransaction(async (tx) => {
            const course = await tx.get(ref);
            if (!course.exists) {
              throw new HttpsError("not-found", "Course not found.");
            }
            tx.update(ref, {archived: true, isOpen: false,
              updatedBy: adminUid, updatedAt: FieldValue.serverTimestamp()});
          });
          return {ok: true};
        }),

    // No login required. The phone is not verified; duplicates are blocked
    // for a *given submitted phone*, not for a confirmed person identity.
    registerForCourse: onCall({region: "us-central1", maxInstances: 10},
        async (request) => {
          const data = request.data || {};
          const courseId = requireCourseId(data.courseId);
          const fullName = limitedText(data.fullName, "fullName", 80, 3);
          const phone = normalizePhone(data.phone);
          const deviceKeyHash = validDeviceKey(data.deviceKey);
          const fcmToken = validToken(data.fcmToken);
          const regId = hash(`course-registration\0${courseId}\0${phone}`);
          await rateLimitPublicRegistration(db, request, deviceKeyHash);
          const courseRef = db.collection("courses").doc(courseId);
          const registrationRef = db.collection("course_registrations")
              .doc(regId);
          const result = await db.runTransaction(async (tx) => {
            const [course, existing] = await Promise.all([
              tx.get(courseRef), tx.get(registrationRef),
            ]);
            if (existing.exists) {
              throw new HttpsError("already-exists",
                  "This phone has already registered for the course.");
            }
            if (!course.exists || course.get("archived") === true ||
                course.get("isOpen") !== true) {
              throw new HttpsError("failed-precondition",
                  "Course is unavailable for registration.");
            }
            const startAt = course.get("startAt");
            if (!(startAt instanceof Timestamp) ||
                startAt.toMillis() <= Date.now()) {
              throw new HttpsError("failed-precondition",
                  "Course registration has closed.");
            }
            const accepted = Number(course.get("acceptedCount")) || 0;
            const pending = Number(course.get("pendingCount")) || 0;
            const capacity = Number(course.get("capacity")) || 0;
            if (accepted + pending >= capacity) {
              throw new HttpsError("resource-exhausted", "Course is full.");
            }
            const isAuto = course.get("registrationMode") === "automatic";
            const status = isAuto ? "accepted" : "pending";
            tx.create(registrationRef, {
              courseId, fullName, phone, deviceKeyHash, fcmToken,
              status, notificationState: "not-sent",
              createdAt: FieldValue.serverTimestamp(),
              decidedAt: isAuto ? FieldValue.serverTimestamp() : null,
              decidedBy: isAuto ? "automatic" : null,
            });
            tx.update(courseRef, isAuto ? {
              acceptedCount: FieldValue.increment(1),
            } : {pendingCount: FieldValue.increment(1)});
            return {registrationId: regId, status};
          });
          return result;
        }),

    // The 256-bit per-installation key authorizes updating ONLY notification
    // destinations and reading status summaries; no PII is returned.
    syncCourseDeviceToken: onCall({region: "us-central1", maxInstances: 10},
        async (request) => {
          const deviceKeyHash = validDeviceKey(request.data?.deviceKey);
          const fcmToken = validToken(request.data?.fcmToken);
          if (!fcmToken) {
            throw new HttpsError("invalid-argument", "Token required.");
          }
          const snapshots = await db.collection("course_registrations")
              .where("deviceKeyHash", "==", deviceKeyHash).limit(100).get();
          const batch = db.batch();
          let updated = 0;
          for (const item of snapshots.docs) {
            if (registrationStates.includes(item.get("status")) &&
                item.get("fcmToken") !== fcmToken) {
              batch.update(item.ref, {fcmToken});
              updated++;
            }
          }
          if (updated > 0) await batch.commit();
          return {updated};
        }),

    myCourseRegistrations: onCall({region: "us-central1", maxInstances: 10},
        async (request) => {
          const deviceKeyHash = validDeviceKey(request.data?.deviceKey);
          const snapshots = await db.collection("course_registrations")
              .where("deviceKeyHash", "==", deviceKeyHash).limit(100).get();
          return {registrations: snapshots.docs.map((item) => ({
            courseId: item.get("courseId"), status: item.get("status"),
            registrationId: item.id,
          }))};
        }),

    decideCourseRegistration: onCall({region: "us-central1",
      maxInstances: 10}, async (request) => {
      const adminUid = await requireAdmin(request);
      const data = request.data || {};
      const courseId = requireCourseId(data.courseId);
      const registrationId = requireRegistrationId(data.registrationId);
      if (!["accepted", "rejected"].includes(data.decision)) {
        throw new HttpsError("invalid-argument", "Invalid decision.");
      }
      const regRef = db.collection("course_registrations")
          .doc(registrationId);
      const courseRef = db.collection("courses").doc(courseId);
      const decision = await db.runTransaction(async (tx) => {
        const [registration, course] = await Promise.all([
          tx.get(regRef), tx.get(courseRef),
        ]);
        if (!registration.exists || registration.get("courseId") !==
            courseId || !course.exists) {
          throw new HttpsError("not-found", "Registration not found.");
        }
        if (registration.get("status") !== "pending") {
          throw new HttpsError("failed-precondition",
              "Registration already decided.");
        }
        tx.update(regRef, {status: data.decision,
          decidedAt: FieldValue.serverTimestamp(), decidedBy: adminUid,
          notificationState: "sending"});
        tx.update(courseRef, data.decision === "accepted" ? {
          pendingCount: FieldValue.increment(-1),
          acceptedCount: FieldValue.increment(1),
        } : {pendingCount: FieldValue.increment(-1)});
        return {...registration.data(), status: data.decision};
      });
      const notified = await sendDecision(db, courseId,
          registrationId, decision);
      return {notified};
    }),

    resendCourseDecision: onCall({region: "us-central1", maxInstances: 10},
        async (request) => {
          await requireAdmin(request);
          const courseId = requireCourseId(request.data?.courseId);
          const registrationId = requireRegistrationId(
              request.data?.registrationId);
          const regRef = db.collection("course_registrations")
              .doc(registrationId);
          const registration = await db.runTransaction(async (tx) => {
            const snapshot = await tx.get(regRef);
            if (!snapshot.exists || snapshot.get("courseId") !== courseId ||
                !["accepted", "rejected"].includes(snapshot.get("status"))) {
              throw new HttpsError("failed-precondition", "No final decision.");
            }
            const last = snapshot.get("lastResendAt");
            if (last instanceof Timestamp &&
                Date.now() - last.toMillis() < 60000) {
              throw new HttpsError("resource-exhausted", "Retry in a minute.");
            }
            tx.update(regRef, {lastResendAt: FieldValue.serverTimestamp(),
              notificationState: "sending"});
            return snapshot.data();
          });
          const notified = await sendDecision(db, courseId,
              registrationId, registration);
          return {notified};
        }),
  };
}

module.exports = {makeCourseFunctions};
